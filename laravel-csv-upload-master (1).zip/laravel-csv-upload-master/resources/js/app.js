import './bootstrap';
// Import all of Bootstrap's CSS
import '../../node_modules/bootstrap/scss/bootstrap.scss';
// Import all of Bootstrap's JS
import * as bootstrap from 'bootstrap';
//Submitting our form functions and button functions
import './components/form';
import './components/buttons';



